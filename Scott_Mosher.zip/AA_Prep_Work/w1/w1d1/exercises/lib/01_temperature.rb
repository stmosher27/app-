def ftoc (fahr)
    (fahr -32)*(5.0/9.0) 
end

def ctof (cels)
    (cels*(9.0/5.0)+32)
end
    